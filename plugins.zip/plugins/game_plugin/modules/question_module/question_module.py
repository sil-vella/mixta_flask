import yaml
import os
import random
from flask import request, jsonify, send_from_directory
from tools.logger.custom_logging import custom_log
from core.managers.module_manager import ModuleManager

# ✅ Get the directory of the current file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ✅ Dynamically set IMAGE_DIR relative to this file's location
IMAGE_DIR = os.path.join(BASE_DIR, "celeb_data", "images")

class QuestionModule:
    def __init__(self, app_manager=None):
        """Initialize QuestionModule and register routes."""
        self.app_manager = app_manager
        self.connection_module = self.get_connection_module()

        if not self.connection_module:
            raise RuntimeError("QuestionModule: Failed to retrieve ConnectionModule from ModuleManager.")

        custom_log("✅ QuestionModule initialized.")

        # ✅ Ensure routes are registered upon module initialization
        self.register_routes()


    def get_connection_module(self):
        """Retrieve ConnectionModule from ModuleManager."""
        module_manager = self.app_manager.module_manager if self.app_manager else ModuleManager()
        return module_manager.get_module("connection_module")

    def register_routes(self):
        """Register question-related routes."""
        if not self.connection_module:
            raise RuntimeError("ConnectionModule is not available yet.")

        # ✅ Register the get-question route
        self.connection_module.register_route('/get-question', self.get_question, methods=['GET'])
        custom_log("🌐 QuestionModule: `/get-question` route registered.")

        # ✅ Register the static image serving route
        def serve_image(filename):
            """Serves images from the /images/ directory."""
            return send_from_directory(IMAGE_DIR, filename)

        self.connection_module.register_route('/images/<path:filename>', serve_image, methods=['GET'])
        custom_log("🖼️ QuestionModule: `/images/<filename>` route registered to serve static images.")

    def load_questions(self):
        """Load questions from YAML file in the celeb_data subdirectory."""
        try:
            # ✅ Get the directory where `question_module.py` is located
            base_dir = os.path.dirname(os.path.abspath(__file__))

            # ✅ Build the absolute path to `celeb_data.yml`
            yaml_path = os.path.join(base_dir, "celeb_data", "celeb_data.yml")

            # ✅ Open and load YAML data with UTF-8 encoding
            with open(yaml_path, "r", encoding="utf-8") as file:
                data = yaml.safe_load(file)

            custom_log(f"✅ Questions loaded successfully from {yaml_path}.")
            return data
        except UnicodeDecodeError as e:
            custom_log(f"❌ Encoding error loading YAML: {e}")
            return None
        except yaml.YAMLError as e:
            custom_log(f"❌ YAML syntax error: {e}")
            return None
        except Exception as e:
            custom_log(f"❌ Unexpected error loading YAML from {yaml_path}: {e}")
            return None


    def get_question(self):
        """Returns a question based on difficulty level and retrieves the actor's image plus 3 distractor images."""
        try:
            level = str(request.args.get("level", default=1, type=int))  # ✅ Ensure level is string
            category = request.args.get("category", default=None, type=str)  # ✅ Retrieve category from request

            # ✅ Retrieve guessed names from request arguments (as a list)
            guessed_names = request.args.getlist("guessed_names[]") or []
            custom_log(f"📄 Received guessed names for category '{category}' at level {level}: {guessed_names}")

            # ✅ Load questions from YAML
            questions = self.load_questions()
            if not questions:
                return jsonify({"error": "Failed to load questions"}), 500

            if level not in questions:
                return jsonify({"error": f"No facts available for level {level}"}), 404

            # ✅ Filter available actors based on category and guessed names
            if category == "mixed":
                all_actors = [
                    actor for actor in questions[level].keys() if actor not in guessed_names
                ]
            else:
                all_actors = [
                    actor for actor, data in questions[level].items()
                    if category in data.get("categories", []) and actor not in guessed_names
                ]

            if not all_actors:
                return jsonify({"error": f"No more actors left to guess in category '{category}' at level {level}"}), 404

            # ✅ Randomly select an actor from the remaining list
            actor = random.choice(all_actors)
            custom_log(f"🎭 Selected actor: {actor} from category: {category}")

            # ✅ Retrieve facts safely
            question_data = questions[level][actor]
            if not question_data or "facts" not in question_data:
                return jsonify({"error": f"No valid facts available for level {level}"}), 404

            # ✅ Get the dynamic base URL from request
            base_url = request.host_url.rstrip('/')
            custom_log(f"🌐 Using dynamic BASE_URL: {base_url}")

            # ✅ Format actor name to match image filenames
            formatted_name = actor.lower().replace(" ", "_")
            custom_log(f"🖼 Searching for image with prefix: {formatted_name}")

            # ✅ Search for the first image matching the celeb name in the images directory
            image_url = None
            if os.path.exists(IMAGE_DIR):
                for filename in os.listdir(IMAGE_DIR):
                    if filename.startswith(formatted_name):
                        image_url = f"{base_url}/images/{filename}"  # ✅ Use dynamic base_url
                        break

            if not image_url:
                custom_log(f"⚠️ No image found for {actor}, using default.")
                image_url = f"{base_url}/images/default.jpg"  # ✅ Use a full default image URL

            # ✅ Get 3 random distractor images (excluding the selected celeb's image)
            distractor_images = []
            all_images = [f for f in os.listdir(IMAGE_DIR) if f.endswith((".jpg", ".png", ".jpeg"))]

            # Remove the main image from the list
            all_images = [f for f in all_images if f != os.path.basename(image_url)]

            if len(all_images) >= 3:
                distractor_images = random.sample(all_images, 3)  # ✅ Pick 3 random images
                distractor_images = [f"{base_url}/images/{img}" for img in distractor_images]
            else:
                distractor_images = [f"{base_url}/images/default.jpg"] * 3  # ✅ Use default images if not enough distractors

            response = {
                "actor": actor,
                "category": category or "unknown",  # ✅ Include category in response
                "facts": question_data["facts"],  # ✅ Retrieve facts safely
                "level": level,
                "image_url": image_url,  # ✅ Add full image URL to response
                "distractor_images": distractor_images  # ✅ Add distractor images
            }

            custom_log(f"🎭 Sending facts for {actor} at level {level} with image: {image_url} and distractors: {distractor_images}")

            return jsonify(response), 200

        except Exception as e:
            custom_log(f"❌ Unexpected error in get_question: {e}")
            return jsonify({"error": f"Server error: {str(e)}"}), 500
